<?php

namespace Diglactic\Breadcrumbs\Exceptions;

use Exception;

/**
 * Base class for exceptions in Laravel Breadcrumbs.
 */
abstract class BaseException extends Exception
{
    //
}
