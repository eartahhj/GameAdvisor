<?php

namespace Illuminate\Database\Events;

class ConnectionEstablished extends ConnectionEvent
{
    //
}
