<?php

namespace Spatie\Honeypot\Exceptions;

use Exception;

class SpamException extends Exception
{
}
